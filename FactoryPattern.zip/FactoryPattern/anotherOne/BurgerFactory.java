package FactoryPattern.anotherOne;

public class BurgerFactory {
    Burger burger;

    public Burger createBurger(String type){
        if(type.equals("beef")){
            burger = new beefBurgers();
        } else if (type.equals("chicken")) {
            burger = new chickenBurgers();
        }


        return burger;
    }
}
