package FactoryPattern.anotherOne;

public class VeggieBurger implements Burger{

    @Override
    public void prepare() {

    }
}
