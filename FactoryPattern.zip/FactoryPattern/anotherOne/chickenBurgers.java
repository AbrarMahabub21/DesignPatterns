package FactoryPattern.anotherOne;

public class chickenBurgers implements Burger{
    String SnydeX;

    @Override
    public void prepare() {

    }
}
