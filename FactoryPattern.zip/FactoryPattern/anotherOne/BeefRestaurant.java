package FactoryPattern.anotherOne;

public class BeefRestaurant extends Restaurant{
    @Override
    public Burger createBurger() {
        return new beefBurgers();
    }
}
