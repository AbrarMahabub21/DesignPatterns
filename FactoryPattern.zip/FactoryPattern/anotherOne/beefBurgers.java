package FactoryPattern.anotherOne;

public class beefBurgers implements Burger{
    String Name;

    @Override
    public void prepare() {

    }
}
