package FactoryPattern.anotherOne;

public class Main {
    public static void main(String[] args){
        Restaurant McDonalds = new ChickenRestaurant();
        Burger chickenBurger = McDonalds.orderBurger();
    }
}
