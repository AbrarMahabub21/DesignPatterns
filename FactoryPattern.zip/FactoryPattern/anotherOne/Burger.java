package FactoryPattern.anotherOne;

public interface Burger {

    public  void prepare();
}
