package FactoryPattern.anotherOne;

public class ChickenRestaurant extends Restaurant{
    @Override
    public Burger createBurger() {
        return  new chickenBurgers();
    }
}
