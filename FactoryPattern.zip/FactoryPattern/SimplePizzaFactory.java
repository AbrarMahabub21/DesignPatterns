package FactoryPattern;

public class SimplePizzaFactory {
    Pizza pizza = null;
    public Pizza createPizza(String type){
       if(type.equals("Cheese")){
           pizza = new CheesePizza();
        } else if (type.equals("Steak")) {
           pizza = new SteakPizza();
       }else if (type.equals("Papper")) {
           pizza = new PapperPizza();
       }
       else {
           pizza = new ClamPizza();
       }
        return pizza;
    }
}
