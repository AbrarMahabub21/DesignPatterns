package FactoryPattern;

public interface Pizza {

    public  void Prepare();
    public void Bake();
    public void cut();
    public void box();

}
