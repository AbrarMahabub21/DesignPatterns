package FactoryPattern;

public class ClamPizza implements Pizza{
    @Override
    public void Prepare() {

    }

    @Override
    public void Bake() {

    }

    @Override
    public void cut() {

    }

    @Override
    public void box() {

    }
}
