package Flyweight_pattern;

public class droneControlSystem {
    public static void main(String[] args) {
        // Simulate a drone with multiple cameras and batteries
        droneComponent[] components = new droneComponent[5];
        components[0] = droneComponentFactory.getComponent("Camera 4K");
        components[1] = droneComponentFactory.getComponent("Battery 3000");
        components[2] = droneComponentFactory.getComponent("Camera HD");
        components[3] = droneComponentFactory.getComponent("Battery 5000");
        components[4] = droneComponentFactory.getComponent("Camera 4K");

        for (droneComponent component : components) {
            if (component != null) {
                component.operate();
            }
        }
    }
}
