package Flyweight_pattern;

import java.util.HashMap;

public class droneComponentFactory {
    private static HashMap<String, droneComponent> components = new HashMap<>();

    public static droneComponent getComponent(String key) {
        if (components.containsKey(key)) {
            return components.get(key);
        } else {
            if (key.contains("Camera")) {
                droneComponent camera = new Camera(key);
                components.put(key, camera);
                return camera;
            } else if (key.contains("Battery")) {
                int capacity = Integer.parseInt(key.split(" ")[1]);
                droneComponent battery = new Battery(capacity);
                components.put(key, battery);
                return battery;
            } else {
                return null;
            }
        }
    }
}
