package Flyweight_pattern;

public interface droneComponent {
    void operate();
}
