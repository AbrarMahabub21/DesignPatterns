package Flyweight_pattern;

public class Camera implements droneComponent{
    private String model;

    public Camera (String model){
        this.model = model;
    }
    @Override
    public void operate() {
        System.out.println("operating            " + model);
    }
}
