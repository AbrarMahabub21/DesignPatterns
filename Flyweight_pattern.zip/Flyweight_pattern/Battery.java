package Flyweight_pattern;

public class Battery implements droneComponent{
    private int Capacity;

    public Battery(int Capacity) {
        this.Capacity = Capacity;
    }
    @Override
    public void operate() {
        System.out.println("operating " + Capacity);
    }
}
