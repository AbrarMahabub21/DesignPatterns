package AdapterPattern;

public class Flash implements Detective_Comics{
    @Override
    public void Power() {
        System.out.println("I have super speed running ability");
    }

    @Override
    public void Detective() {
        System.out.println("I am a detective \n");
    }
}
