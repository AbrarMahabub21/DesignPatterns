package AdapterPattern.musicType;

public class mediaAdapter implements mediaPlayer{

    advancedMediaPlayer advance;

    public mediaAdapter(String type){
        if(type.equals("VLC")){
            advance = new vlcPlayer();
        } else if (type.equals("mp4")) {
            advance = new videoPlayer();
        }
    }
    @Override
    public void play(String audioType, String fileName) {
        if(audioType.equals("VLC")){
            advance.playVLC(fileName);
        } else if (audioType.equals("MP4")){
            advance.playMP4(fileName);

        }
    }
}
