package AdapterPattern.musicType;

public class videoPlayer implements advancedMediaPlayer{
    @Override
    public void playVLC(String name) {
        //do nothing

    }

    @Override
    public void playMP4(String name) {
        System.out.println("Playing mp4" + name);

    }
}
