package AdapterPattern.musicType;

public class justMedia implements mediaPlayer{
    mediaAdapter media;


    @Override
    public void play(String audioType, String fileName) {
        if(audioType.equals("VLC") || audioType.equals("MP4")){
            media = new mediaAdapter(audioType);
            media.play(audioType,fileName);
        }
    }
}
