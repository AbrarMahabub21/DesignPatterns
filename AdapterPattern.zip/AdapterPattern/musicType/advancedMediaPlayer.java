package AdapterPattern.musicType;

public interface advancedMediaPlayer {

    public void playVLC(String name);
    public void playMP4(String name);
}
