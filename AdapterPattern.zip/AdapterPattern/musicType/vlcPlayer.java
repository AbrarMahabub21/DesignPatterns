package AdapterPattern.musicType;

public class vlcPlayer implements advancedMediaPlayer{
    @Override
    public void playVLC(String name) {
        System.out.println("playing VLC" + name);
    }

    @Override
    public void playMP4(String name) {
        //do nothing

    }
}
