package AdapterPattern.musicType;

public interface mediaPlayer {
    public void play(String audioType, String fileName);
}
