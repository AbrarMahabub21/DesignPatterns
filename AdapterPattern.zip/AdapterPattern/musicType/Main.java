package AdapterPattern.musicType;

public class Main {
    public static void main(String[] args){
        justMedia media = new justMedia();

        media.play("VLC","Legends never die");
        media.play("MP4", "Spike");
    }
}
