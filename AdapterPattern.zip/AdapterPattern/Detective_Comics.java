package AdapterPattern;

public interface Detective_Comics {
    public void Power();
    public void Detective();
}
