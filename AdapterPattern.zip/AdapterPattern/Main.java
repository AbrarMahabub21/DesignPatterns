package AdapterPattern;

public class Main {
    public static void main(String[] args){
        Flash flash2 = new Flash();
        IronMan IronMan2 = new IronMan();
        Detective_Comics adapter = new AdapterPatternClass(IronMan2);
        IronMan2.Power();
        IronMan2.ability();
        flash2.Power();
        flash2.Detective();
        TestAdapter(flash2);
        TestAdapter(adapter);

    }

    static void TestAdapter(Detective_Comics detective){
        detective.Detective();
        detective.Power();
    }




}
