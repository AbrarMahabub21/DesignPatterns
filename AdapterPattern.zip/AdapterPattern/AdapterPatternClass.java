package AdapterPattern;

public class AdapterPatternClass implements Detective_Comics{
        Marvel marvel;

        public AdapterPatternClass(Marvel marvel){
            this.marvel = marvel;
        }
    @Override
    public void Power() {
        marvel.Power();
    }

    @Override
    public void Detective() {
        marvel.ability();
    }
}
