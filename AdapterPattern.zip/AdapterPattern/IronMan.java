package AdapterPattern;

public class IronMan implements Marvel{
    @Override
    public void Power() {
        System.out.println("I have laser beam power \n");
    }

    @Override
    public void ability() {
        System.out.println("I can Fly");
    }
}
