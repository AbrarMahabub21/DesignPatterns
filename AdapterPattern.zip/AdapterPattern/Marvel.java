package AdapterPattern;

public interface Marvel {
    public void Power();
    public void ability();


}
