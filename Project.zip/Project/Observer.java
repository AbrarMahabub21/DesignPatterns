package Project;

public interface Observer {
    void update(observeQuack duck);
}
