package Project;

public class gooseAdapter implements Quackable{
    Goose goose;

    public gooseAdapter(Goose goose){
        this.goose = goose;
    }
    @Override
    public void quack() {
        goose.honk();
    }

    @Override
    public void registerObserver(Observer observer) {

    }

    @Override
    public void notifyObservers() {

    }
}
