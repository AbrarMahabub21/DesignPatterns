package Project;

public class countingDuckFactory extends duckFactory{
    public Quackable createDihanDuck(){
        return new quackCounter(new dihanDuck());
    }

    @Override
    public Quackable createWonderDuck() {
        return new quackCounter(new wonderDuck());
    }
}
