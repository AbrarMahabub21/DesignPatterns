package Project;

public class duckSimulator {
    public static void main(String[] args){
            duckFactory dummy_duck = new duckFactory();
            countingDuckFactory dummy_counting = new countingDuckFactory();

            Quackable dihanDuck = dummy_duck.createDihanDuck();
            Quackable wonderDuck = dummy_duck.createWonderDuck();
            Quackable goose = new gooseAdapter(new Goose());

            Flock flock = new Flock();

            flock.add(dihanDuck);
            flock.add(wonderDuck);
            flock.add(goose);

            System.out.println("Floak Simulator: ");
            simulate(flock);
    }
    static void simulate(Quackable duck){
        duck.quack();
    }

}
