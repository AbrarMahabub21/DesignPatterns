package Project;

public class quackCounter implements Quackable {
    Quackable duck;
    int cnt = 0;
    public quackCounter (Quackable duck){
        this.duck = duck;
    }


    @Override
    public void quack() {
        duck.quack();
        cnt++;
    }

    public int getCounter(){
        return cnt;
    }

    @Override
    public void registerObserver(Observer observer) {

    }

    @Override
    public void notifyObservers() {

    }
}
