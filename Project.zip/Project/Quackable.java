package Project;

public interface Quackable extends observeQuack {
    public void quack();
}
