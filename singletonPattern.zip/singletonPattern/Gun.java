package singletonPattern;

public class Gun {
    int magazine;
    String name;
    static Gun vandal = new Gun();
    public void gunName() {
        System.out.println("this gun is Reaver vandal");
    }

    private Gun(){

    }

    public static Gun getVandal(){
        return vandal;
    }
}
