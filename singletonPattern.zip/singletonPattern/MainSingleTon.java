package singletonPattern;

public class MainSingleTon {
    public static void main (String[] args){
      Gun  dummy_gun = Gun.getVandal();

      dummy_gun.gunName();
    }
}
