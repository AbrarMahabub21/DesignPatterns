package compositePattern;

public class compositeClass {
    public static void main(String[] args){
        Employee CEO = new Employee("Nowrid","CSE",50000);
        Employee Executives = new Employee("Abrar","CSE",70000);
        Employee MarketingManager = new Employee("Humaira","MF",60000);
        Employee clerk1 = new Employee("Adib","EEE",25000);
        Employee clerk2 = new Employee("aftab","CEE",20000);
        Employee headSales = new Employee("dihan","MPE", 50000);

        CEO.add(Executives);
        CEO.add(MarketingManager);

        headSales.add(clerk1);
        headSales.add(clerk2);

        System.out.println(CEO);
        for(Employee head : CEO.getSubordinates()){
            System.out.println(head);
        }

    }



}
