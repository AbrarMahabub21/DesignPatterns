package VisitorPattern;

public class reloadCalculator implements reloadVisitor{
    @Override
    public double reloadVandal(Vandal vandal) {
        return vandal.getVandalBullet()/25;
    }

    @Override
    public double reloadPhantom(Phantom phantom) {
        return phantom.getPhantomBullet()/30;
    }
}
