package VisitorPattern;

import java.util.ArrayList;
import java.util.List;

public class WeaponCollection {
    List<Weapon>gun = new ArrayList<>();

    public void add(Weapon weapon){
        gun.add(weapon);
    }

    public List<Double> calculate(reloadVisitor reload){
            List<Double>calculation = new ArrayList<>();

            for(Weapon i : gun){
                calculation.add(i.Visitor(reload));
            }

            return calculation;
    }
}
