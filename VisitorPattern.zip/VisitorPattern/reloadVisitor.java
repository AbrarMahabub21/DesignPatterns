package VisitorPattern;

public interface reloadVisitor {
    public double reloadVandal(Vandal vandal);
    public double reloadPhantom(Phantom phantom);
}
