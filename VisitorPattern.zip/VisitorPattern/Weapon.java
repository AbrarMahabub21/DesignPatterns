package VisitorPattern;

public interface Weapon {
     double Visitor(reloadVisitor reload);
}
