package VisitorPattern;

public class Vandal implements Weapon{
    private double bullets;

    public Vandal(double bullets){
        this.bullets = bullets;
    }

    public double getVandalBullet(){
        return bullets;
    }
    @Override
    public double Visitor(reloadVisitor reload) {
        return reload.reloadVandal(this);
    }


}
