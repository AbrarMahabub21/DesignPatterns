package VisitorPattern;

public class Phantom implements Weapon{
    private double bullets;
    public Phantom(double bullets){
        this.bullets = bullets;
    }
    public double getPhantomBullet(){
        return bullets;
    }
    @Override
    public double Visitor(reloadVisitor reload) {
        return reload.reloadPhantom(this);
    }


}
