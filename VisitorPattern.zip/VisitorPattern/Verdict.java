package VisitorPattern;



public class Verdict {
    public static void main(String[] args){
        Vandal Reaver = new Vandal(75);
        Phantom Oni = new Phantom(90);
        Vandal PreludeToChaos = new Vandal(50);
        Phantom Glitchpop = new Phantom(60);

        WeaponCollection inventory = new WeaponCollection();

        inventory.add(Reaver);
        inventory.add(Oni);
        inventory.add(PreludeToChaos);
        inventory.add(Glitchpop);

        reloadCalculator calc = new reloadCalculator();

        inventory.calculate(calc);

        System.out.println(inventory.calculate(calc));

    }
}
