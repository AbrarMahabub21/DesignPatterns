package StrategyPattern;

public class Main {
    public  static void main(String[] args) {
      Calculator calculator = new Calculator(2,3,new Add());
      System.out.println(calculator.calculation());

      calculator = new Calculator(3,2,new Subs());
      System.out.println(calculator.calculation());

      calculator = new Calculator(2,3,new Mul());
      System.out.println(calculator.calculation());

    }
}
