package StrategyPattern;

public class Football implements sports{
    @Override
    public void play() {
        System.out.println("will play football now!");
    }
}
