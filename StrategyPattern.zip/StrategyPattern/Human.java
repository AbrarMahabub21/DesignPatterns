package StrategyPattern;

public class Human {
    String name;
    sports sports;

    public Human(String name, sports sports){
        this.name = name;
        this.sports = sports;
    }

    public void willPlay(){
        System.out.println(name+" ");
        sports.play();

    }
}
