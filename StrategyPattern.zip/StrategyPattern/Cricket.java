package StrategyPattern;

public class Cricket implements sports{
    @Override
    public void play() {
        System.out.println("will play Cricket now!");
    }
}
