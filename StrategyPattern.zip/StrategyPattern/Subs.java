package StrategyPattern;

public class Subs implements Strategy{
    @Override
    public int doOperation(int a, int b) {
        return a-b;
    }
}
