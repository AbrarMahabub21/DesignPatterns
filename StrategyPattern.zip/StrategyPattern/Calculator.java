package StrategyPattern;

public class Calculator {
    int a ;
    int b;
    Strategy strategy;

    public Calculator( int a , int b, Strategy strategy){
        this.a= a;
        this.b = b;
        this.strategy = strategy;
    }

    public int calculation (){
        return strategy.doOperation(a,b);
    }
}
