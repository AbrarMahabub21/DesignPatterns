package StrategyPattern;

public class implementHuman {
    public static void main(String[] args){
        Human human = new Human("Nowrid", new Cricket());
        human.willPlay();

        human = new Human("Humaira", new Football());
        human.willPlay();
    }
}
