package StrategyPattern;

public interface sports {
    public void play();
}
