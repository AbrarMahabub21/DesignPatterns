package StrategyPattern;

public class Mul implements Strategy{
    @Override
    public int doOperation(int a, int b) {
        return a*b;
    }
}
