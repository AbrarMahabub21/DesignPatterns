package AgentSelection_lab_03_StrategyPattern;

public class Neon implements Agents{

    public int life;
    @Override
    public int life(int damaged, int shield) {
       life = (100-damaged)+shield;
        return life;
    }

    @Override
    public void Intro() {
        System.out.println("Neon is a duelist agent. She is from Philippines");
    }

    @Override
    public void Usage() {
        System.out.println("Neon is Useful in Breeze,Pearl,Sunset maps\n");
    }
}
