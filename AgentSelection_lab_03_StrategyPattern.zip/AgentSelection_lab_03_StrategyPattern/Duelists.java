package AgentSelection_lab_03_StrategyPattern;

public class Duelists {
    int damage;
    Agents agents;
    int shield;
    int total;

    String name;

    public Duelists(String name,int damage,int shield, Agents agents){
        this.damage = damage;
        this.shield = shield;
        this.agents = agents;
        this.name = name;
    }

    public int getLife(){
       total =  agents.life(damage,shield);
        return total;
    }
    public void others(){
        agents.Intro();
        agents.Usage();
    }
}
