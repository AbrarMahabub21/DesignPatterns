package AgentSelection_lab_03_StrategyPattern;

public class Jett implements Agents{
    public int life;

    @Override
    public int life(int damaged, int shield) {
        life = (100-damaged)+shield;
        return life;
    }

    @Override
    public void Intro() {
       System.out.println("Jett is a duelist agent. She is from Korea");
    }

    @Override
    public void Usage() {
        System.out.println("Jett is Useful in Bind,Split,Icebox maps\n");
    }
}
