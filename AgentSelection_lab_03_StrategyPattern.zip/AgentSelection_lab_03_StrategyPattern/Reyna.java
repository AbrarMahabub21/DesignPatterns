package AgentSelection_lab_03_StrategyPattern;

public class Reyna implements Agents{
    public int life;

    @Override
    public int life(int damaged, int shield) {
        life = (100-damaged)+shield;
        return life;
    }

    @Override
    public void Intro() {
        System.out.println("Reyna is a duelist agent. She is from Mexico");
    }

    @Override
    public void Usage() {
        System.out.println("Reyna is Useful in Fracture,Lotus,Icebox maps\n");
    }
}
