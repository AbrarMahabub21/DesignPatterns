package AgentSelection_lab_03_StrategyPattern;

public class Phoenix implements Agents {

public int life;
    @Override
    public int life(int damaged, int shield) {
        life = (100-damaged)+shield;
        return life;
    }

    @Override
    public void Intro() {
        System.out.println("Phoenix is a duelist agent. he is from United Kingdom");
    }

    @Override
    public void Usage() {
        System.out.println("Phoenix is Useful in Heaven,Fracture,Bind maps\n");
    }
}
