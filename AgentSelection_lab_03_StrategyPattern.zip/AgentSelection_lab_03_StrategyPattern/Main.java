package AgentSelection_lab_03_StrategyPattern;

public class Main {
    public static void main(String[] args){
        Duelists chosen_duelist = new Duelists("Jett",10,25,new Jett());
        int total_life = chosen_duelist.getLife() ;
        System.out.println("total life of "+chosen_duelist.name+" is "+total_life);
        chosen_duelist.others();

         chosen_duelist = new Duelists("Reyna",20,50,new Reyna());
         total_life = chosen_duelist.getLife() ;
        System.out.println("total life of "+chosen_duelist.name+" is "+total_life);
        chosen_duelist.others();

        chosen_duelist = new Duelists("Phoenix",90,50,new Phoenix());
        total_life = chosen_duelist.getLife() ;
        System.out.println("total life of "+chosen_duelist.name+" is "+total_life);
        chosen_duelist.others();

        chosen_duelist = new Duelists("Neon",100,50,new Neon());
        total_life = chosen_duelist.getLife() ;
        System.out.println("total life of "+chosen_duelist.name+" is "+total_life);
        chosen_duelist.others();

    }
}
