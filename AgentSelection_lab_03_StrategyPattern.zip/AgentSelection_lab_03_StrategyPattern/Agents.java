package AgentSelection_lab_03_StrategyPattern;

public interface Agents {

    public int life(int damaged, int shield);
    public void Intro();
    public void Usage();
}
