package statePattern;

public class ReloadingState implements characterState{
    @Override
    public void startRunning() {
        System.out.println("Stop reloading and start running.");
    }

    @Override
    public void startShooting() {
        System.out.println("Cannot shoot while reloading.");
    }

    @Override
    public void startReloading() {
        System.out.println("Already reloading.");
    }
}
