package statePattern;

public class ValorantCharacter {
    private characterState currentState;

    public ValorantCharacter() {
        this.currentState = new runningState(); // Initial state
    }

    public void setState(characterState state) {
        this.currentState = state;
    }

    public void startRunning() {
        currentState.startRunning();
    }

    public void startShooting() {
        currentState.startShooting();
    }

    public void startReloading() {
        currentState.startReloading();
    }
}
