package statePattern;

public class ShootingState implements characterState{
    @Override
    public void startRunning() {
        System.out.println("Stop shooting and start running.");
    }

    @Override
    public void startShooting() {
        System.out.println("Already shooting.");
    }

    @Override
    public void startReloading() {
        System.out.println("Cannot reload while shooting.");
    }
}
