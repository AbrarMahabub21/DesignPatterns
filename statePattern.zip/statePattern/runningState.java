package statePattern;

public class runningState implements characterState{
    @Override
    public void startRunning() {
        System.out.println("Already running.");
    }

    @Override
    public void startShooting() {
        System.out.println("Start shooting while running.");
    }

    @Override
    public void startReloading() {
        System.out.println("Cannot reload while running.");
    }
}
