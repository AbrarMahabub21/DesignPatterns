package statePattern;

public interface characterState {
    void startRunning();
    void startShooting();
    void startReloading();
}
