package statePattern;

public class Main {
    public static void main(String[] args) {
        ValorantCharacter player = new ValorantCharacter();

        player.startRunning();    // Output: Already running.
        player.startShooting();   // Output: Start shooting while running.
        player.startReloading();  // Output: Cannot reload while running.

        player.setState(new ShootingState());
        player.startReloading();  // Output: Cannot reload while shooting.
    }
}
