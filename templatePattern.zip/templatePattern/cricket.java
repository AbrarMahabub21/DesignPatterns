package templatePattern;

public class cricket extends Sports{

    @Override
    public void sportsName(){
        System.out.println("This is cricket");
    }

    @Override
    public void startSport(){
        System.out.println("start Cricket sport");
    }

    @Override
    public void endSport(){
        System.out.println("end Cricket sport");
    }




}
