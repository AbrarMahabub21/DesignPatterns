package templatePattern;

public abstract class Sports {
    public String name;

    public void sportsName(){
        System.out.println("this is a base class");
    }

    public void startSport(){
        System.out.println("this is a base class");
    }

    public void endSport(){
        System.out.println("this is a base class");
    }

    public void allFunc(){
        sportsName();
        startSport();
        endSport();
    }
}
