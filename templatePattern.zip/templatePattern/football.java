package templatePattern;

public class football extends Sports{
    @Override
    public void sportsName(){
        System.out.println("This is football");
    }

    @Override
    public void startSport(){
        System.out.println("start football sport");
    }

    @Override
    public void endSport(){
        System.out.println("end football sport");
    }



}
