package templatePattern;

public class Main {
    public  static void main(String[] args){
        cricket dummy_cricket = new cricket();
        football dummy_football = new football();

        System.out.println("THIS IS CRICKET PART");
        dummy_cricket.allFunc();

        System.out.println("THIS IS FOOTBALL PART");
        dummy_football.allFunc();
    }
}
